"""
Módulo principal de la aplicación FasAPI
"""