

from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.user import UserORM
from typing import Annotated # Nueva Importación
from fastapi import Cookie # Nueva Importación

templates = Jinja2Templates(directory="app/templates")

router = APIRouter(prefix="/users", tags=["web"])

@router.get("", response_class=HTMLResponse)
def list_users(request: Request, db: Session = Depends(get_db)):
    users = db.execute(select(UserORM)).scalars().all()

    return templates.TemplateResponse(
        "user/list.html",
        {"request": request, "users": users}
    )

@router.get("/{user_id}", response_class=HTMLResponse)
def detail_by_id(request: Request, user_id: int, db: Session = Depends(get_db)):
    user = db.execute(select(UserORM).where(UserORM.id == user_id)).scalar_one_or_none()

    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"No existe ningún usuario con el id {user_id}")
    
    return templates.TemplateResponse(
        "user/detail.html",
        {"request": request, "user": user}
    )

# =================================================================
# NUEVOS ENDPOINTS PARA SELECCIÓN/DESELECCIÓN DE USUARIO (Simulación de Sesión)
# =================================================================

@router.post("/select", response_class=RedirectResponse)
def select_user(
    user_id: Annotated[int, Form(...)],
    db: Session = Depends(get_db) # Opcional: para validar que el ID existe
):
    """
    Selecciona un usuario por ID y establece una cookie 'current_user_id'.
    """
    # En un caso real, validaríamos que el usuario existe antes de establecer la cookie
    if db.get(UserORM, user_id) is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Usuario no encontrado")

    # Redirigir al inicio o a la biblioteca
    response = RedirectResponse(url="/videogame", status_code=status.HTTP_303_SEE_OTHER)
    
    # Establecer la cookie (httponly=True por seguridad básica)
    response.set_cookie(
        key="current_user_id", 
        value=str(user_id), 
        httponly=True, 
        max_age=3600*24*30 # 30 días de "sesión"
    )
    
    return response

@router.post("/deselect", response_class=RedirectResponse)
def deselect_user():
    """
    Elimina la cookie de usuario actual.
    """
    # Redirigir al inicio
    response = RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)
    response.delete_cookie(key="current_user_id")
    return response