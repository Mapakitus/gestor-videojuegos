from fastapi import APIRouter, Depends, Form, HTTPException, Request, status, Cookie
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import select, and_
from sqlalchemy.orm import Session, selectinload
from typing import Annotated
from app.database import get_db
from app.models.genre import GenreORM
from app.models.user import UserORM
from app.models.videogame import VideogameORM
from app.models.review import ReviewORM # Importar ReviewORM


templates = Jinja2Templates(directory="app/templates/")

router = APIRouter(prefix="/videogame", tags=["web"])

# show all games

@router.get("", response_class=HTMLResponse)
def list_videogames(request: Request, db: Session = Depends(get_db)):
    videogames = db.execute(select(VideogameORM)).scalars().all()
    last_games = db.execute(select(VideogameORM).order_by(VideogameORM.id.desc()).limit(3)).scalars().all()
    
    if not videogames:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="404 - Base de datos no encontrada")
    

    return templates.TemplateResponse(
        "home.html",
        {"request": request, "videogames": videogames, "last_games": last_games}
    )

# show form create videogame
    
@router.get("/new", response_class=HTMLResponse)
def form_create(request: Request, db: Session = Depends(get_db)):
    return templates.TemplateResponse(
        "videogame/form.html",
        {"request": request, "videogame": None}
    )


# create new videogame

@router.post("/new", response_class=HTMLResponse)
def create(
    request: Request,
    title:str = Form(...),
    description: str = Form(None),
    cover_url: str = Form(None),
    genre_id: str = Form(None),
    developer_id: str = Form(None),
    db: Session = Depends(get_db)
    ):

    errors = []

    form_data = {
        "title": title,
        "description": description,
        "cover_url": cover_url,
        "genre_id": genre_id,
        "developer_id": developer_id
    }

    if not title or not title.strip():
        errors.append("El título del videojuego no puede estar vacío")

    description_value = None
    if description and description.strip():
        description_value = description.strip()

    cover_url_value = None
    if cover_url and cover_url.strip():
        cover_url_value = cover_url.strip()

    genre_id_value = None
    if genre_id and genre_id.strip():
        try:
            genre_id_value = int(genre_id.strip())
            if genre_id_value < 0:
                errors.append("El género id no puede ser negativo")
        except ValueError:
            errors.append("El id debe ser un número válido")

    developer_id_value = None
    if developer_id and developer_id.strip():
        try:

            developer_id_value = int(developer_id.strip())
            if developer_id_value < 0:
                errors.append("El desarrolladora id no puede ser negativo")
        except ValueError:
            errors.append("El id debe ser un número válido")

    if errors:
        return templates.TemplateResponse(
            "videogame/form.html",
            {"request": request, "videogame": None, "errors": errors, "form_data": form_data}
        )
    
    try:

        new_game = VideogameORM(
            title=title.strip(),
            description=description_value,
            cover_url=cover_url_value,
            genre_id=genre_id_value,
            developer_id=developer_id_value
        )

        db.add(new_game)
        db.commit()
        db.refresh(new_game)

        return RedirectResponse(url=f"/videogame/{new_game.id}", status_code=303)
    except Exception as e:
        db.rollback()
        errors.append(f"Error al crear el videojuego: {str(e)}")
        return templates.TemplateResponse(
            "videogame/form.html",
            {"request": request, "videogame": None, "errors": errors, "form_data": form_data}
        )
    
# show detail videogame

@router.get("/{game_id}", response_class=HTMLResponse)
def game_detail(game_id: int, request: Request, db: Session = Depends(get_db)):
    videogame = db.execute(select(VideogameORM).where(VideogameORM.id == game_id)).scalar_one_or_none()
    genre = db.execute(select(GenreORM).where(GenreORM.id == videogame.genre_id)).scalar_one_or_none()
    

    if videogame is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"404 - No existe ningún videojuego con el id {game_id}")
    
    return templates.TemplateResponse(
        "videogame/detail.html",
        {"request": request, "videogame": videogame, "genre": genre}
    )


# edit videogame by id

@router.get("/{game_id}/edit", response_class=HTMLResponse)
def form_edit(request: Request, game_id: int, db: Session = Depends(get_db)):
    game = db.execute(select(VideogameORM).where(VideogameORM.id == game_id)).scalar_one_or_none()

    if game is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="404 - No existe este videojuego")
     
    return templates.TemplateResponse(
         "videogame/form.html",
         {"request": request, "game": game}
    )


# 

@router.post("/{game_id}/edit", response_class=HTMLResponse)
def edit_videogame(
    request: Request, 
    game_id: int,
    title: str = Form(...),
    description: str = Form(None),
    cover_url: str = Form(None),
    genre_id: str = Form(None),
    developer_id: str = Form(None),
    db: Session = Depends(get_db)               
):

    game = db.execute(select(VideogameORM).where(VideogameORM.id == game_id)).scalar_one_or_none()

    if game is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="404 - No existe este videojuego")
    
    errors = []

    form_data = {
        "title": title,
        "description": description,
        "cover_url": cover_url,
        "genre_id": genre_id,
        "developer_id": developer_id
    }

    if not title or not title.strip():
        errors.append("El título no puede estar vacío")

    title_value = title.strip()

    description_value = None
    if description and description.strip():
        description_value = description.strip()

    cover_url_value = None
    if cover_url and cover_url.strip():
        cover_url_value = cover_url

    genre_id_value = None
    if genre_id and genre_id.strip():
        try:
            genre_id_value = int(genre_id.strip())
            if genre_id_value < 0:
                errors.append("El id no puede ser un número negativo")
        except ValueError:
            errors.append("El id tiene que ser un número válido")

    developer_id_value = None
    if developer_id and developer_id.strip():
        try:
            developer_id_value = int(developer_id.strip())
            if developer_id_value < 0:
                errors.append("El id no puede ser un número negativo")
        except ValueError:
            errors.append("El id tiene que ser un número válido")

    if errors:
        return templates.TemplateResponse(
            "videogames/form.html",
            {"request": request, "game": game, "errors": errors, "form_data": form_data}
        )
    
    try:
        game.title = title_value
        game.description = description_value
        game.cover_url = cover_url_value
        game.genre_id = genre_id_value
        game.developer_id = developer_id_value

        db.commit()
        db.refresh(game)

        return RedirectResponse(url=f"/videogame/{game.id}", status_code=303)
    except Exception as e:
        db.rollback()
        errors.append(f"No se ha podido crea el videojuego: {str(e)}")
        return templates.TemplateResponse(
            "videogame/form.html",
            {"request": request, "game": game, "errors": errors, "form_data": form_data}
        )

# =================================================================
# FUNCIÓN DE UTILIDAD (DEPENDENCIA) PARA OBTENER EL ID DEL USUARIO
# =================================================================
def get_current_user_id_or_none(
    request: Request, 
    current_user_id: Annotated[str | None, Cookie(alias="current_user_id")] = None
) -> int | None:
    if current_user_id:
        try:
            return int(current_user_id)
        except ValueError:
            return None
    return None

# =================================================================
# NUEVO ENDPOINT: VER MI BIBLIOTECA
# =================================================================
@router.get("/library", response_class=HTMLResponse)
def view_library(
    request: Request, 
    db: Session = Depends(get_db), 
    user_id: int | None = Depends(get_current_user_id_or_none)
):
    if user_id is None:
        # Si no hay usuario seleccionado, redirigir a la selección
        return RedirectResponse(url="/users", status_code=status.HTTP_303_SEE_OTHER)

    # Cargar el usuario y su biblioteca (selectinload(UserORM.videogames))
    user = db.execute(
        select(UserORM)
        .where(UserORM.id == user_id)
        .options(selectinload(UserORM.videogames)) 
    ).scalar_one_or_none()
    
    if user is None:
        # ID de cookie inválido, borrar cookie y redirigir
        response = RedirectResponse(url="/users", status_code=status.HTTP_303_SEE_OTHER)
        response.delete_cookie(key="current_user_id")
        return response

    return templates.TemplateResponse(
        "videogame/library.html", # Nueva plantilla
        {"request": request, "user": user, "videogames": user.videogames}
    )

# =================================================================
# ENDPOINT MODIFICADO: DETALLE DE VIDEOJUEGO
# =================================================================
@router.get("/{game_id}", response_class=HTMLResponse)
def detail_videogame(
    request: Request, 
    game_id: int, 
    db: Session = Depends(get_db),
    user_id: int | None = Depends(get_current_user_id_or_none) # Obtener ID de usuario
):
    # Cargar el videojuego, incluyendo reviews y usuarios (para check de propiedad)
    game = db.execute(
        select(VideogameORM)
        .where(VideogameORM.id == game_id)
        .options(selectinload(VideogameORM.reviews))
        .options(selectinload(VideogameORM.users))
    ).scalar_one_or_none()
    
    if not game:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"No existe el videojuego con el id {game_id}")
    
    is_owned = False
    current_review = None
    
    if user_id:
        # 1. Comprobar si el usuario actual tiene el juego (propiedad)
        is_owned = any(user.id == user_id for user in game.users)
        
        # 2. Obtener la review del usuario actual (si existe)
        current_review = db.execute(
            select(ReviewORM).where(
                and_(ReviewORM.user_id == user_id, ReviewORM.videogame_id == game_id)
            )
        ).scalar_one_or_none()


    # Pasar la información a la plantilla
    return templates.TemplateResponse(
        "videogame/detail.html", # Modificar esta plantilla
        {
            "request": request, 
            "game": game, 
            "user_id": user_id, 
            "is_owned": is_owned,
            "current_review": current_review
        }
    )

# =================================================================
# NUEVO ENDPOINT: DESCARGAR (Añadir a la biblioteca)
# =================================================================
@router.post("/{game_id}/download", response_class=RedirectResponse)
def add_to_library(
    game_id: int, 
    db: Session = Depends(get_db), 
    user_id: int | None = Depends(get_current_user_id_or_none)
):
    if user_id is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Debe seleccionar un usuario para descargar.")
        
    user = db.get(UserORM, user_id)
    game = db.get(VideogameORM, game_id)
    
    if not user or not game:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Usuario o Videojuego no encontrado")

    if game not in user.videogames:
        user.videogames.append(game) # Añadir a la biblioteca (tabla user_game)
        db.commit()

    return RedirectResponse(url=f"/videogame/{game_id}", status_code=status.HTTP_303_SEE_OTHER)

# =================================================================
# NUEVO ENDPOINT: DESINSTALAR (Eliminar de la biblioteca)
# =================================================================
@router.post("/{game_id}/uninstall", response_class=RedirectResponse)
def remove_from_library(
    game_id: int, 
    db: Session = Depends(get_db), 
    user_id: int | None = Depends(get_current_user_id_or_none)
):
    if user_id is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Debe seleccionar un usuario para desinstalar.")

    user = db.execute(select(UserORM).where(UserORM.id == user_id).options(selectinload(UserORM.videogames))).scalar_one_or_none()
    game = db.get(VideogameORM, game_id)

    if not user or not game:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Usuario o Videojuego no encontrado")
    
    if game in user.videogames:
        user.videogames.remove(game) # Elimina la entrada en la tabla user_game
        # La review (ReviewORM) PERMANECE en la base de datos, cumpliendo el requisito.
        db.commit()

    return RedirectResponse(url=f"/videogame/{game_id}", status_code=status.HTTP_303_SEE_OTHER)

# =================================================================
# NUEVO ENDPOINT: ENVIAR/ACTUALIZAR REVIEW
# =================================================================
@router.post("/{game_id}/review", response_class=RedirectResponse)
def submit_review(
    game_id: int, 
    rating: Annotated[float, Form(...)], 
    comment: Annotated[str | None, Form(...)] = None,
    db: Session = Depends(get_db), 
    user_id: int | None = Depends(get_current_user_id_or_none)
):
    if user_id is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Debe seleccionar un usuario para dejar una reseña.")
        
    user = db.get(UserORM, user_id)
    game = db.get(VideogameORM, game_id)

    if not user or not game:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Usuario o Videojuego no encontrado")
        
    try:
        # Validar rating (0.0 a 10.0)
        rating_value = float(rating)
        if not (0.0 <= rating_value <= 10.0):
             # En un entorno web, manejarías este error en el formulario/template
             raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="La nota debe estar entre 0.0 y 10.0.")
    except (ValueError, TypeError):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Formato de nota inválido.")

    # Buscar si ya existe una review del usuario para este juego
    review = db.execute(
        select(ReviewORM).where(
            and_(ReviewORM.user_id == user_id, ReviewORM.videogame_id == game_id)
        )
    ).scalar_one_or_none()

    comment_value = comment.strip() if comment else None

    if review:
        # Actualizar review existente
        review.rating = rating_value
        review.comment = comment_value
    else:
        # Crear nueva review
        new_review = ReviewORM(
            rating=rating_value,
            comment=comment_value,
            user_id=user_id,
            videogame_id=game_id
        )
        db.add(new_review)

    db.commit()
    # Redirigir de vuelta al detalle del juego
    return RedirectResponse(url=f"/videogame/{game_id}", status_code=status.HTTP_303_SEE_OTHER)


    


            
